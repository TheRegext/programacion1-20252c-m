///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


///Dada una lista de n�meros que finaliza cuando se ingresa un cero,
///informar cu�l es el primer y segundo n�mero PRIMO ingresado.'


using namespace std;


int main(){
    int num, primerPrimo, segundoPrimo;
    int cantPrimos=0, i, contadorDivisores=0;
    cout<<"INGRESAR NUMERO ";
    cin>>num;
    while(num!=0){
       contadorDivisores=0;
        ///CALCULO PRIMO
       for(i=1;i<=num;i++){
            if(num%i==0){
                contadorDivisores++;
            }
        }
        ///FIN CALCULO PRIMO
        if(contadorDivisores==2 && cantPrimos<2){
            cantPrimos++;
            if(cantPrimos==1){
                primerPrimo=num;
            }
            if(cantPrimos==2){
                segundoPrimo=num;
            }
        }

        cout<<"INGRESAR NUMERO ";
        cin>>num;
    }

	cout<<"PRIMER PRIMO INGRESADO "<<primerPrimo<<endl;
	cout<<"SEGUNDO PRIMO INGRESADO "<<segundoPrimo<<endl;
	system("pause");
	return 0;
}
