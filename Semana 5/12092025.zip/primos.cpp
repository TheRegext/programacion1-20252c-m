///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;


int main(){

	int num, i, contadorDivisores=0;
	cout<<"INGRESAR NUMERO ";
	cin>>num;
	for(i=1;i<=num;i++){
        if(num%i==0){
            contadorDivisores++;
        }
	}
	if(contadorDivisores==2){
        cout<<num<<" ES PRIMO"<<endl;
	}
	else{
        cout<<num<<" NO ES PRIMO"<<endl;
	}
	system("pause");
	return 0;
}
