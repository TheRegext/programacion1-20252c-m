///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;

/// Hacer un programa que acepte un conjunto de n�meros que se ingresan y que corte en el ingreso cuando aparece un segundo
///valor mayor a 100. Informar cu�l es el promedio entre los valores ingresados

///Este procedimiento es utilizado para el control de una m�quina, y debe ejecutarse 5 veces


int main(){
    float prom=1.1;
    int num, cont=0;
    int i;
    for(i=1;i<=5;i++){
        cont=0;
        while(cont<2){
            cout<<"INGRESAR NUMERO ";
            cin>>num;
            if(num>100){
                cont++;
            }

        }
        cout<<" EL PROMEDIO ES "<<prom<<endl;
        system("pause");
        system("cls");
    }
	return 0;
}

