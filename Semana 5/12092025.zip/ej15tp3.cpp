///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>

///Dada una lista de n�meros que finaliza cuando se ingresa un cero,
///informar cu�l es el primer y segundo n�mero impar ingresado.'

using namespace std;


int main(){
    int num, primerImpar, segundoImpar;
    int cantImpares=0;
    cout<<"INGRESAR NUMERO ";
    cin>>num;
    while(num!=0){
        if(num%2==1){
            if(cantImpares==0){
                ///primer impar
                primerImpar=num;
            }
            else{
                if(cantImpares==1){
                    segundoImpar=num;
                }
            }
            cantImpares++;
        }

        cout<<"INGRESAR NUMERO ";
        cin>>num;
    }

	cout<<"PRIMER IMPAR INGRESADO "<<primerImpar<<endl;
	cout<<"SEGUNDO IMPAR INGRESADO "<<segundoImpar<<endl;
	system("pause");
	return 0;
}
